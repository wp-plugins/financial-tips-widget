=== Financial Tips ===
Contributors: bluewaves
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=VWZC5KNTQ7DG8
Tags: financial tips, finance, personal finance, daily automatic updates, finance, finance quotes, saving money, budgeting, investing money, 
Stable: 1.1
Requires at least: 2.6
Tested up to: 3.4.2


Displays random financial tips in admin panel, a text widget and in posts. Also allows custom tips to be added by the user.

== Description ==

Need fresh content for your blog? Display financial tips or tips from any other topic you choose, on your WordPress blog. Simple to use and easy to customize. 

Financial tips are chosen from 6 categories. 38 quotes are taken from various financial experts and good common sense finance rules. Designed to help you add fresh content to your
blog on a daily, weekly or monthly basis without having to update by hand.

To get the financial tips to appear, you go to widgets, then select financial tips and drag it 
to your sidebar area. There you can choose the category you want to display and how often you want it to change.

Want to install tips that you pick out? That is easy to do too. In the financial tips settings menu, just click on "add new."
Your new category, along with your new tip will appear. Add hundreds of tips if you like. Happy blogging!




== Installation ==

1. Upload the `financial tips` directory to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress





