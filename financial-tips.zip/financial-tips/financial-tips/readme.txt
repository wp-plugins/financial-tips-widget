=== Financial Tips ===
Contributors: bluewaves
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=VWZC5KNTQ7DG8
Tags: financial tips, custom text widget, rotating text, finance, finance quotes, saving money, budgeting, investing money, personal finance
Stable: 1.0
Requires at least: 2.6
Tested up to: 3.4.2


Displays random default and customized financial tips in admin panel, text widget and in posts. Financial tips from finance experts. 

== Description ==

This plugin displays random quotes and tips concerning personal finance and financial stability in a text widget.
This plugin also displays random financial tips on every admin page. These are daily, weekly or monthly tips that will help you establish
a firm foundation in handling your personal finance and building a secure future. Default tips are included, but you can add your
own tips.


== Installation ==

1. Upload the `financial tips` directory to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress





